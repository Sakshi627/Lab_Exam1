package com.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class MyClass {

	public static void main(String[] args) {
		System.setProperty("webdriver.firefox.driver",
				"D:\\myseleniumdata\\geckodriver-v0.34.0-win32\\geckodriver.exe");

		WebDriver d1 = new FirefoxDriver();
		d1.get("https://www.opencart.com/index.php?route=account/register");
		
		String s = d1.getTitle();
		System.out.println("The Current URL IS" +d1.getCurrentUrl());
		
		d1.findElement(By.xpath("//input[@id='input-username']")).sendKeys("sakshi123");
		d1.findElement(By.xpath("//input[@id='input-firstname']")).sendKeys("sakshi");
		d1.findElement(By.xpath("//input[@id='input-lastname']")).sendKeys("Bhonde");
		d1.findElement(By.xpath("//input[@id='input-email']")).sendKeys("sakshi@gmail.com");
		d1.findElement(By.xpath("//input[@id='input-email']")).sendKeys("12345");
		Select city = new Select(d1.findElement(By.xpath("//select[@id='input-country']")));
	    city.selectByIndex(6);
		 
		 
		 d1.findElement(By.xpath("//body/div[@id='account-register']/div[@id='register']/div[1]/div[1]/form[1]/div[7]/button[2]")).click();
		 
		 
		 d1.findElement(By.xpath("//input[@id='input-email']")).sendKeys("sakshi@gmail.com");
		 d1.findElement(By.xpath("//input[@id='input-password']")).sendKeys("sakshi123");
		 d1.findElement(By.xpath("//body/div[@id='account-login']/div[2]/div[1]/div[1]/form[1]/div[3]/div[1]/button[2]")).click();
		 
		 
		 
		 WebElement email = d1.findElement(By.xpath("//input[@id='input-email']"));
		 email.sendKeys("sakshi@gmail.com");
		 String printemail = email.getAttribute("value");
		 System.out.println(printemail);
		 
		 
		 WebElement pass = d1.findElement(By.xpath("//input[@id='input-password']"));
		 pass.sendKeys("1234");
		 String printpass = email.getAttribute("value");
		 System.out.println(printpass);
		 
		 
//		 d1.findElement(By.xpath("//input[@id='input-email']")).sendKeys("sakshi@gmail.com");
//		 String Email = d1.findElement(By.xpath("")).getAttribute("value");
//		 
		 
		 
		 
		  
		
		
	}

}
